var indexSectionsWithContent =
{
  0: "_abcdefghijklmnopqrstuvwxyz~串为主光决前卡参图在基如安定导平并序弃引待扩支数整旋最机构检海激特目相硬神类系聚能补装视读责迈追通重顶",
  1: "acdefghiklmoprstuv",
  2: "cr",
  3: "abcdefghiklmoprstuv",
  4: "abcdefghijklmnoprstuvwyz~",
  5: "_abcdefghiklmnopqrstvxyz",
  6: "acdfhkmprsuv",
  7: "_acegmprtv",
  8: "abcdefghijklmnopqrstuvwxyz",
  9: "or",
  10: "acdfgmopt串光决前卡参图基定平并序支数整旋机检海激特目相神类系能补装视迈追重",
  11: "akor串为主光卡参在基如安导并弃引待扩支最构相硬聚视读责通顶"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "namespaces",
  3: "files",
  4: "functions",
  5: "variables",
  6: "typedefs",
  7: "enums",
  8: "enumvalues",
  9: "defines",
  10: "groups",
  11: "pages"
};

var indexSectionLabels =
{
  0: "全部",
  1: "类",
  2: "命名空间",
  3: "文件",
  4: "函数",
  5: "变量",
  6: "类型定义",
  7: "枚举",
  8: "枚举值",
  9: "宏定义",
  10: "组",
  11: "页"
};

