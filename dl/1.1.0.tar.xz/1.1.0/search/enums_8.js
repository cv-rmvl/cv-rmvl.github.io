var searchData=
[
  ['tagtype_1861',['TagType',['../d6/d59/group__types.html#ga53b2ed651ce89a5884af7310fb1a24d6',1,'rm']]],
  ['targetchangetype_1862',['TargetChangeType',['../d6/d59/group__types.html#gab039850f02ebbd12cc2ea0951d741a22',1,'rm']]]
];
