var searchData=
[
  ['区间搜索_0',['1 区间搜索',['../de/d14/tutorial_modules_fminbnd.html#autotoc_md169',1,'']]],
  ['区间消去_1',['2.1 区间消去',['../de/d14/tutorial_modules_fminbnd.html#autotoc_md171',1,'']]]
];
